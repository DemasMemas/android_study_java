package com.example.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Integer counter = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickBtnAddStudents(View view) {
        counter++;
        TextView counterView = findViewById(R.id.txt_counter);
        counterView.setText(counter.toString());
        TextView bublicView = findViewById(R.id.bublic_text);
        char counterLastSymbol = counter.toString().charAt(counter.toString().length() - 1);
        if (counterLastSymbol == '1' & !counter.toString().equals("11")){
            bublicView.setText("БУБЛИК");
        }
        else if((counterLastSymbol == '2' | counterLastSymbol == '3' | counterLastSymbol == '4')
                & !counter.toString().equals("12") & !counter.toString().equals("13") & !counter.toString().equals("14")){
            bublicView.setText("БУБЛИКА");
        }
        else{
            bublicView.setText("БУБЛИКОВ");
        }
    }
}